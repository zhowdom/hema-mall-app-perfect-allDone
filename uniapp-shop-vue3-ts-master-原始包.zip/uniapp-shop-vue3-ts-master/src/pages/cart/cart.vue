<script setup lang="ts">
import CartMain from './components/CartMain.vue'
</script>

<template>
  <CartMain />
</template>

<style lang="scss">
page {
  height: 100%;
}
</style>
